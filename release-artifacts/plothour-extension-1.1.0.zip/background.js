const ext = typeof chrome !== 'undefined' ? chrome : browser;
let mutation = Promise.resolve();
function validOrigin(value) {
  const url = new URL(value);
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))) throw new Error('Use HTTPS, or a localhost address for development.');
  return url.origin;
}
async function connection() { const data = await ext.storage.local.get(['studyduel_server_url','studyduel_token']); return { origin: data.studyduel_server_url || 'https://plothour.com', token: data.studyduel_token }; }
async function api(path, options = {}, config) {
  const { origin, token } = config || await connection();
  let response;
  for (let attempt=0; attempt<2; attempt++) {
    try { response = await fetch(`${validOrigin(origin)}/api${path}`, { credentials: 'omit', ...options, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, signal: AbortSignal.timeout(15000) }); break; }
    catch(error) { if(attempt===1 || !path.startsWith('/timer/')) throw error; }
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
async function badge(activeTimer) {
  const seconds = activeTimer ? Math.max(0, Math.floor(((activeTimer.pausedAt || Date.now()) - activeTimer.startedAt) / 1000 - (activeTimer.pausedSeconds || 0))) : 0;
  await ext.action.setBadgeText({ text: activeTimer ? activeTimer.pausedAt ? 'Ⅱ' : seconds < 60 ? '●' : seconds < 3600 ? `${Math.floor(seconds / 60)}m` : `${(seconds / 3600).toFixed(1)}h` : '' });
  await ext.action.setBadgeBackgroundColor({ color: '#746eac' });
}
async function saveTimer(activeTimer) { await ext.storage.local.set({ studyduel_active_timer: activeTimer }); await badge(activeTimer); }
async function getState() {
  const config = await connection();
  if (!config.token) return { origin: config.origin, user: null, projects: [], activeTimer: null };
  const [account, projects, timer] = await Promise.all([api('/auth/me'), api('/projects'), api('/timer/active')]);
  await saveTimer(timer.activeTimer);
  return { origin: config.origin, user: account.user, projects: projects.projects, activeTimer: timer.activeTimer };
}
async function handle(req) {
  if (req.type === 'LOGIN') {
    const origin = validOrigin(req.origin);
    const data = await api('/auth/login', { method: 'POST', body: JSON.stringify({ email: req.email, password: req.password }) }, { origin });
    if (!data.token || !data.user) throw new Error('This server did not return an authenticated session.');
    await ext.storage.local.set({ studyduel_server_url: origin, studyduel_token: data.token });
    return { origin, user: data.user };
  }
  if (req.type === 'GET_STATE') return getState();
  if (req.type === 'CONNECT_TAB') {
    const tabs = await ext.tabs.query({ url: ['http://localhost/*','http://127.0.0.1/*','https://plothour.com/*','https://www.plothour.com/*'] });
    for (const tab of tabs.sort((a,b) => Number(b.active) - Number(a.active))) {
      try {
        const result = await ext.tabs.sendMessage(tab.id, { type: 'CONNECT_SESSION' });
        if (!result?.token || !result.user) continue;
        const origin = validOrigin(tab.url);
        await ext.storage.local.set({ studyduel_server_url: origin, studyduel_token: result.token });
        return { origin, user: result.user };
      } catch { /* Try the next signed-in app tab. */ }
    }
    throw new Error('Open your PlotHour app and sign in first, or sign in here using your app address.');
  }
  if (req.type === 'START_TIMER' || req.type === 'STOP_TIMER') {
    const result = await api(`/timer/${req.type === 'START_TIMER' ? 'start' : 'stop'}`, { method: 'POST', body: JSON.stringify({ projectId: req.projectId, subjectId: req.subjectId, expectedStartedAt: req.expectedStartedAt, commandId: crypto.randomUUID() }) });
    await saveTimer(result.activeTimer);
    return result;
  }
  if (req.type === 'LOGOUT') { await ext.storage.local.remove(['studyduel_token','studyduel_user','studyduel_projects','studyduel_time_entries']); await saveTimer(null); return {}; }
  if (req.type === 'OPEN_WEBAPP') { const { origin } = await connection(); await ext.tabs.create({ url: `${validOrigin(origin)}/timer` }); return {}; }
  throw new Error('Unknown extension action.');
}
ext.runtime.onMessage.addListener((req, sender, reply) => {
  // Only extension pages may trigger account and timer actions.
  if (sender.tab || !sender.url?.startsWith(ext.runtime.getURL(''))) return false;
  const execute = () => handle(req).then(data => reply({ ...data, success: true })).catch(error => reply({ success: false, error: error.message }));
  mutation = mutation.then(execute, execute);
  return true;
});
ext.alarms.create('timer-refresh', { periodInMinutes: .5 });
ext.alarms.onAlarm.addListener(() => getState().catch(() => {}));
ext.runtime.onStartup.addListener(() => getState().catch(() => {}));
