// No storage sniffing or timer writes: the authenticated server owns the session.
const ext = typeof chrome !== 'undefined' ? chrome : browser;
ext.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== ext.runtime.id || message.type !== 'CONNECT_SESSION') return false;
  (async () => {
    const response = await fetch('/api/auth/extension-session', { credentials: 'same-origin', method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    respond(response.ok ? await response.json() : null);
  })().catch(() => respond(null));
  return true;
});
