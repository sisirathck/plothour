// The browser app keeps its HTTP-only cookie. No token or localStorage sniffing.
const ext = typeof chrome !== 'undefined' ? chrome : browser;
const allowedRequests = new Set(['GET /auth/me','GET /projects','GET /timer/active','GET /timer/entries','POST /timer/start','POST /timer/stop','POST /timer/pause','POST /timer/resume']);
ext.runtime.onMessage.addListener((message,sender,respond) => {
  if(sender.id!==ext.runtime.id || message.type!=='AUTHENTICATED_REQUEST') return false;
  const method=message.method || 'GET';
  if(!allowedRequests.has(`${method} ${message.path}`)) {respond({status:403,data:{error:'This request is not available to the timer extension.'}});return false;}
  (async()=>{
    const response=await fetch(`/api${message.path}`,{method,credentials:'same-origin',headers:{'Content-Type':'application/json'},...(method==='POST'?{body:message.body || '{}'}:{}),signal:AbortSignal.timeout(15000)});
    respond({status:response.status,data:await response.json().catch(()=>({}))});
  })().catch(()=>respond({status:503,data:{error:'Could not reach the app. Keep the PlotHour tab open and retry.'}}));
  return true;
});
